if ! echo ${PATH} | /bin/grep -q /opt/dell/srvadmin/iSM/bin; then
	PATH=${PATH}:/opt/dell/srvadmin/iSM/bin
fi

